to active the Smilies after instalation goto [your forum name]/admin/?area=smileys;sa=modifyset

original article >> https://justinmidlet.blogspot.com/2019/05/unicode-emoji-smilies-for-simple.html