note:to active the Smilies after instalation goto [your forum name]/admin/?area=smileys;sa=modifyset


unicode emoji v1.0 mod for SMF is licensed under MIT and CC-BY 4.0
>>https://justinmidlet.blogspot.com/2019/05/unicode-emoji-smilies-for-simple.html

emoji icons are licensed to:
Copyright 2019 Twitter, Inc and other contributors
Code licensed under the MIT License: http://opensource.org/licenses/MIT
Graphics licensed under CC-BY 4.0: https://creativecommons.org/licenses/by/4.0/
>>https://twemoji.twitter.com/